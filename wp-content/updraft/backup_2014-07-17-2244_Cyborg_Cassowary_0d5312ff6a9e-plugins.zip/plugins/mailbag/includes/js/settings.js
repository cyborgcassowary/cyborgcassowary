jQuery(document).ready(function( $ ) { 

	$( "#tabs" ).tabs(); 
	
});
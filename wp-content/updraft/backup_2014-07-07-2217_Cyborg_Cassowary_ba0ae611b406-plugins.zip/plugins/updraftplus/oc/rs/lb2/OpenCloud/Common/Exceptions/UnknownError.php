<?php

namespace OpenCloud\Common\Exceptions;

class UnknownError extends \Exception {}

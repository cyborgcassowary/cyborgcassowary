Stitch is a clean, modern theme in cool tones, with support for one widget area, custom drop-down menus, custom header and background, multiple post formats, and a mobile-friendly, responsive design.

By default, Stitch’s main header, menu, and optional sidebar stay fixed to the left of the screen as the content scrolls by on the right. This limits the amount of content you can include in this area, so if you’d prefer to turn off this functionality, you can do so under Appearance -> Themes -> Customize -> Theme Options.


Changelog
================

v1.07 - Minor bug fix for infinite scroll in functions.php
v1.06 - Update readme with theme documentation; fix $content_width; minor tweaks to code in functions.php
v1.05 - Fix Theme URI, move separator within entry meta such that extra separators do not appear if only one category is used, add support for Jetpack Infinite Scroll
v1.0 - Hello, world!
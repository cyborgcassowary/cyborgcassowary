<?php

namespace OpenCloud\Common\Exceptions;

class FlavorError extends \Exception {}

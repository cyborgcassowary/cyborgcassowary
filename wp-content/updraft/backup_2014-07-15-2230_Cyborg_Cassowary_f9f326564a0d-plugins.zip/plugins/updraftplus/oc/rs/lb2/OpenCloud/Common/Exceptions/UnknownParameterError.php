<?php

namespace OpenCloud\Common\Exceptions;

class UnknownParameterError extends \Exception {}
